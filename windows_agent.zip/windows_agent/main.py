# ============================================================
# windows_agent/main.py
# ============================================================

from __future__ import annotations

import logging
import os
import warnings

# ============================================================
# TensorFlow / OCR logging configuration
# ============================================================

os.environ.setdefault(
    "TF_CPP_MIN_LOG_LEVEL",
    "3",
)

os.environ.setdefault(
    "ABSL_MIN_LOG_LEVEL",
    "2",
)

os.environ.setdefault(
    "TF_ENABLE_ONEDNN_OPTS",
    "0",
)

for logger_name in (
    "tensorflow",
    "tensorflow_hub",
    "tf_keras",
    "absl",
):
    logging.getLogger(
        logger_name
    ).setLevel(
        logging.ERROR
    )

warnings.filterwarnings(
    "ignore",
    category=DeprecationWarning,
)

warnings.filterwarnings(
    "ignore",
    category=FutureWarning,
)

warnings.filterwarnings(
    "ignore",
    message=r".*is deprecated.*",
)

warnings.filterwarnings(
    "ignore",
    module=r".*tensorflow.*",
)

warnings.filterwarnings(
    "ignore",
    module=r".*tensorflow_hub.*",
)

warnings.filterwarnings(
    "ignore",
    module=r".*tf_keras.*",
)


# ============================================================
# FastAPI
# ============================================================

from fastapi import FastAPI, HTTPException, UploadFile


# ============================================================
# Agent components
# ============================================================

from windows_agent.agent.current_screen_memory import (
    CurrentScreenMemory,
)

from windows_agent.agent.uia_information import (
    UIAInformation,
)

from windows_agent.agent.perception_memory import (
    GetImportantFramesTool,
    ScreenPerception,
)

from windows_agent.agent.llm import (
    LocalLLM,
)

from windows_agent.agent.memory_db.chromadb import (
    UserMemory,
)

from windows_agent.tools.find_ui_target import (
    FindUITarget,
)

from windows_agent.tools.action_tools import (
    ActionTools,
)

from windows_agent.tools.tool_manager import (
    ToolManager,
)

from windows_agent.tools.windows_ocr import (
    WindowsOCR,
)

from windows_agent.agent.voice.stt.service import (
    STTService,
)

from windows_agent.agent.voice.tts.service import (
    TTSService,
)

from windows_agent.agent.voice.tts.engine import (
    TTSEngine,
)


# ============================================================
# FastAPI application
# ============================================================

app = FastAPI(
    title="Windows Local AI Agent",
)


# ============================================================
# 1. Core screen/UI components
# ============================================================

uia_information = UIAInformation()

screen_perception = ScreenPerception(
    uia_information,
)

current_screen_memory = CurrentScreenMemory()


# ============================================================
# 2. IMPORTANT:
# Initialize LocalLLM BEFORE WindowsOCR.
#
# We experimentally verified:
#
#     Llama -> OCR  = PASS
#     OCR   -> Llama = ACCESS VIOLATION
#
# ============================================================

llm = LocalLLM()


# ============================================================
# 3. Initialize OCR AFTER Llama
# ============================================================

ocr = WindowsOCR()


# ============================================================
# 4. Perception / targeting tools
# ============================================================

important_frames_tool = GetImportantFramesTool(
    screen_perception,
)

find_ui_target_tool = FindUITarget(
    current_screen_memory,
    uia_information,
    ocr,
)


# ============================================================
# 5. Action tools
# ============================================================

action_tools = ActionTools()


# ============================================================
# 6. User memory
# ============================================================

user_memory = UserMemory()


# ============================================================
# 7. ToolManager
# ============================================================

tool_manager = ToolManager(
    important_frames_tool=important_frames_tool,
    find_ui_target_tool=find_ui_target_tool,
    action_tools=action_tools,
    user_memory=user_memory,
    current_screen_memory=current_screen_memory,
)


# ============================================================
# 8. Attach ToolManager AFTER Llama initialization
# ============================================================

llm.set_tool_manager(
    tool_manager
)


# ============================================================
# 9. TTS
# ============================================================

tts_engine = TTSEngine()

tts_service = TTSService(
    engine=tts_engine,
    output_path="response.wav",
)


# ============================================================
# Startup status
# ============================================================

print(
    "Windows Local AI Agent initialized successfully."
)

print(
    "Qwen3-VL: READY"
)

print(
    "WindowsOCR: READY"
)

print(
    "ToolManager: READY"
)

print(
    "TTS: READY"
)


# ============================================================
# API endpoint
# ============================================================

@app.post("/execute")
async def execute_agent(
    audio: UploadFile,
) -> dict[str, str]:
    """
    Receive an audio request and process it through the local agent.

    The audio is transcribed with the STT service, passed to the
    current LLM/tool pipeline, and the final response is spoken using
    the local TTS service.
    """

    audio_data = await audio.read()

    if not audio_data:
        raise HTTPException(
            status_code=400,
            detail="Audio input is empty.",
        )

    transcribed_query = STTService.process_audio(
        audio_data,
    )

    if not transcribed_query:
        raise HTTPException(
            status_code=400,
            detail="No speech was detected.",
        )

    # --------------------------------------------------------
    # IMPORTANT:
    #
    # Your current LocalLLM architecture uses process_step()
    # rather than the old process() method.
    #
    # The actual multi-step execution loop will be connected
    # here later.
    # --------------------------------------------------------

    try:

        decision = llm.process_step(
            user_query=transcribed_query,
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=f"Agent execution failed: {exc}",
        ) from exc

    # --------------------------------------------------------
    # If Qwen immediately says "done", return it.
    #
    # Actual tool-execution loop will be added separately.
    # --------------------------------------------------------

    if decision.get(
        "status"
    ) == "done":

        final_response = llm.final_response(
            user_query=transcribed_query,
            execution_result={
                "status": "done",
            },
        )

    else:

        final_response = (
            f"Selected tool: "
            f"{decision.get('tool', 'unknown')}"
        )

    tts_service.speak(
        final_response,
        "en",
    )

    return {
        "status": "completed",
        "response": final_response,
    }


# ============================================================
# Shutdown
# ============================================================

@app.on_event(
    "shutdown"
)
def shutdown() -> None:
    """
    Release the local Llama model during application shutdown.

    This ensures the native model resources are released cleanly
    when the FastAPI application terminates.
    """

    llm.close()